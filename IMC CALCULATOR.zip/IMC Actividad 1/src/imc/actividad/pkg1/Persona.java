/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imc.actividad.pkg1;

import javax.swing.JOptionPane;

/**
 *
 * @author PC RICARDO
 */
public class Persona {
    
    private float estatura;
    private float peso;
    private float imc;
    
    
    public float getEstatura(){
        return estatura;
    }
    
    public void setEstatura(float e){
        estatura = e;
    }
    
    public float getPeso(){
        return peso;
    }
    
    public void setPeso(float p){
        peso = p;
    }
    
    public float getIMC(){
        return imc;
    }
    
    public void setIMC(){
        
        imc = getPeso() / (getEstatura() * getEstatura());
    }
    
    public void mostrarIMC(){
        
        JOptionPane.showMessageDialog(null, " Su IMC es: " + getIMC());
        
        if(getIMC() < 18.5){
            JOptionPane.showMessageDialog(null, "Bajo Peso");
        }
        else  if (getIMC() >= 18.5 && getIMC() <= 24.9){
         JOptionPane.showMessageDialog(null, "Peso Normal");   
        }
        else  if (getIMC() >= 25 && getIMC() <= 29.9){
         JOptionPane.showMessageDialog(null, "Sobrepeso");   
        }
        else  if (getIMC() >= 30 && getIMC() <= 34.9){
         JOptionPane.showMessageDialog(null, "Obesidad Tipo 1");   
        }
        else  if (getIMC() >= 35 && getIMC() <= 39.9){
         JOptionPane.showMessageDialog(null, "Obesidad Tipo 2");   
        }
        else {
              JOptionPane.showMessageDialog(null, "Obesidad Tipo 3"); 
        }
    }
    
    
}
